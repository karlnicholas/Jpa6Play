# School Management System

This is a Spring Boot REST API for managing a school system, including schools, students, courses, and instructors. It uses Spring Data JPA with an H2 in-memory database to implement CRUD operations and specific business logic, such as adding students to courses, with efficient SQL query generation.

## Prerequisites
- Java 21
- Maven 3.6+
- An HTTP client (e.g., Postman or curl) for testing API endpoints

## How to Run
1. Clone the repository or unzip the project folder.
2. Navigate to the project directory:
   ```bash
   cd school-management-system
   ```
3. Build and run the application using Maven:
   ```bash
   mvn spring-boot:run
   ```
4. The application will start on `http://localhost:8080`. The H2 console is available at `http://localhost:8080/h2-console` (use JDBC URL: `jdbc:h2:mem:schooldb`, username: `sa`, password: empty).

## API Endpoints

### SchoolController (`/api/school`)
- **GET** `/{name}`: Retrieve a school by name.
  - Example: `curl http://localhost:8080/api/school/Springfield%20High`
  - Response: `200 OK` with `SchoolDto` or `404 Not Found`.

### StudentController (`/api/student`)
- **POST**: Create a student.
  - Example: `curl -X POST http://localhost:8080/api/student?schoolId=1 -H "Content-Type: application/json" -d '{"name":"John Doe"}'`
  - Response: `201 Created` with `StudentDto`.
- **GET** `/{name}`: Retrieve a student by name.
  - Example: `curl http://localhost:8080/api/student/John%20Doe`
  - Response: `200 OK` with `StudentDetailDto` or `404 Not Found`.
- **GET**: Retrieve all students.
  - Example: `curl http://localhost:8080/api/student`
  - Response: `200 OK` with `List<StudentDto>`.
- **PUT** `/{name}`: Update a student by name.
  - Example: `curl -X PUT http://localhost:8080/api/student/John%20Doe -H "Content-Type: application/json" -d '{"name":"John Smith"}'`
  - Response: `200 OK` with `StudentDto` or `404 Not Found`.
- **DELETE** `/{name}`: Delete a student by name.
  - Example: `curl -X DELETE http://localhost:8080/api/student/John%20Doe`
  - Response: `200 OK` or `404 Not Found`.

### CourseController (`/api/course`)
- **POST**: Create a course.
  - Example: `curl -X POST http://localhost:8080/api/course?schoolId=1&instructorId=1 -H "Content-Type: application/json" -d '{"name":"Mathematics"}'`
  - Response: `201 Created` with `CourseDto`.
- **GET** `/{name}`: Retrieve a course by name.
  - Example: `curl http://localhost:8080/api/course/Mathematics`
  - Response: `200 OK` with `CourseDetailDto` or `404 Not Found`.
- **GET**: Retrieve all courses.
  - Example: `curl http://localhost:8080/api/course`
  - Response: `200 OK` with `List<CourseDto>`.
- **PUT** `/{name}`: Update a course by name.
  - Example: `curl -X PUT http://localhost:8080/api/course/Mathematics?instructorId=2 -H "Content-Type: application/json" -d '{"name":"Advanced Mathematics"}'`
  - Response: `200 OK` with `CourseDto` or `404 Not Found`.
- **DELETE** `/{name}`: Delete a course by name.
  - Example: `curl -X DELETE http://localhost:8080/api/course/Mathematics`
  - Response: `200 OK` or `404 Not Found`.
- **POST** `/{courseName}/students/{studentName}`: Add a student to a course.
  - Example: `curl -X POST http://localhost:8080/api/course/Mathematics/students/John%20Doe`
  - Response: `200 OK` or `404 Not Found` (if course or student not found) or `400 Bad Request` (if not in same school).

### InstructorController (`/api/instructor`)
- **POST**: Create an instructor.
  - Example: `curl -X POST http://localhost:8080/api/instructor?schoolId=1 -H "Content-Type: application/json" -d '{"name":"Jane Smith"}'`
  - Response: `201 Created` with `InstructorDto`.
- **GET** `/{name}`: Retrieve an instructor by name.
  - Example: `curl http://localhost:8080/api/instructor/Jane%20Smith`
  - Response: `200 OK` with `InstructorDetailDto` or `404 Not Found`.
- **GET**: Retrieve all instructors.
  - Example: `curl http://localhost:8080/api/instructor`
  - Response: `200 OK` with `List<InstructorDto>`.
- **PUT** `/{name}`: Update an instructor by name.
  - Example: `curl -X PUT http://localhost:8080/api/instructor/Jane%20Smith -H "Content-Type: application/json" -d '{"name":"Jane Doe"}'`
  - Response: `200 OK` with `InstructorDto` or `404 Not Found`.
- **DELETE** `/{name}`: Delete an instructor by name.
  - Example: `curl -X DELETE http://localhost:8080/api/instructor/Jane%20Smith`
  - Response: `200 OK` or `404 Not Found`.

## SQL Query Optimization
The `POST /{courseName}/students/{studentName}` endpoint (`CourseService.addStudentToCourse`) is optimized to minimize database load:
- **Custom Query**: Uses a `@Query` annotation in `CourseRepository` to directly insert into the `student_course` join table (`INSERT INTO student_course (student_id, course_id) VALUES (:studentId, :courseId)`).
- **Efficiency**: This approach avoids loading the entire `Course` or `Student` entities into memory, reducing overhead. It generates a single `INSERT` statement, which is executed transactionally to ensure data consistency.
- **Validation**: Checks that the student and course belong to the same school before adding, preventing invalid relationships and reducing unnecessary database operations.
- **SQL Generated**:
  ```sql
  INSERT INTO student_course (student_id, course_id) VALUES (?, ?)
  ```
  This query is minimal, directly targeting the join table without additional joins or updates, ensuring optimal performance.

## Testing
To test the application:
1. Start the application (`mvn spring-boot:run`).
2. Use an HTTP client to send requests to the endpoints listed above.
3. Example sequence to test relationships:
   - Create a school: `POST /api/school` with `{"name":"Springfield High"}`.
   - Create a student: `POST /api/student?schoolId=1` with `{"name":"John Doe"}`.
   - Create an instructor: `POST /api/instructor?schoolId=1` with `{"name":"Jane Smith"}`.
   - Create a course: `POST /api/course?schoolId=1&instructorId=1` with `{"name":"Mathematics"}`.
   - Add student to course: `POST /api/course/Mathematics/students/John%20Doe`.
   - Retrieve course details: `GET /api/course/Mathematics` to verify the student is enrolled.

The application ensures all relationships are correctly maintained, with lazy loading to minimize unnecessary data fetching and efficient SQL queries for all operations.
