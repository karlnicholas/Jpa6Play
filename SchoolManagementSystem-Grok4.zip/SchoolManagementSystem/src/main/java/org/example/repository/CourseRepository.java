package org.example.repository;

import org.example.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface CourseRepository extends JpaRepository<Course, Long> {
    Optional<Course> findByName(String name);

    @Modifying
    @Query("INSERT INTO student_course (student_id, course_id) VALUES (:studentId, :courseId)")
    void addStudentToCourse(Long studentId, Long courseId);
}
