package org.example.service;

import lombok.RequiredArgsConstructor;
import org.example.dto.CourseDetailDto;
import org.example.dto.CourseDto;
import org.example.model.Course;
import org.example.model.Instructor;
import org.example.model.School;
import org.example.model.Student;
import org.example.repository.CourseRepository;
import org.example.repository.InstructorRepository;
import org.example.repository.SchoolRepository;
import org.example.repository.StudentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CourseService {
    private final CourseRepository courseRepository;
    private final SchoolRepository schoolRepository;
    private final InstructorRepository instructorRepository;
    private final StudentRepository studentRepository;

    @Transactional
    public CourseDto createCourse(CourseDto courseDto, Long schoolId, Long instructorId) {
        School school = schoolRepository.findById(schoolId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "School not found"));
        Instructor instructor = instructorId != null ? instructorRepository.findById(instructorId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Instructor not found")) : null;
        if (courseDto.name() == null || courseDto.name().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Course name is required");
        }
        Course course = new Course();
        course.setName(courseDto.name());
        course.setSchool(school);
        course.setInstructor(instructor);
        course = courseRepository.save(course);
        return new CourseDto(course.getId(), course.getName());
    }

    public CourseDetailDto getCourseByName(String name) {
        Course course = courseRepository.findByName(name)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Course not found"));
        return new CourseDetailDto(
                course.getId(),
                course.getName(),
                course.getInstructor() != null ? new org.example.dto.InstructorDto(course.getInstructor().getId(), course.getInstructor().getName()) : null,
                course.getStudents().stream().map(s -> new org.example.dto.StudentDto(s.getId(), s.getName())).collect(Collectors.toList())
        );
    }

    public List<CourseDto> getAllCourses() {
        return courseRepository.findAll().stream()
                .map(c -> new CourseDto(c.getId(), c.getName()))
                .collect(Collectors.toList());
    }

    @Transactional
    public CourseDto updateCourse(String name, CourseDto courseDto, Long instructorId) {
        Course course = courseRepository.findByName(name)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Course not found"));
        Instructor instructor = instructorId != null ? instructorRepository.findById(instructorId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Instructor not found")) : null;
        if (courseDto.name() == null || courseDto.name().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Course name is required");
        }
        course.setName(courseDto.name());
        course.setInstructor(instructor);
        course = courseRepository.save(course);
        return new CourseDto(course.getId(), course.getName());
    }

    @Transactional
    public void deleteCourse(String name) {
        Course course = courseRepository.findByName(name)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Course not found"));
        courseRepository.delete(course);
    }

    @Transactional
    public void addStudentToCourse(String courseName, String studentName) {
        Course course = courseRepository.findByName(courseName)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Course not found"));
        Student student = studentRepository.findByName(studentName)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Student not found"));
        if (!course.getSchool().getId().equals(student.getSchool().getId())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Student and course must belong to the same school");
        }
        courseRepository.addStudentToCourse(student.getId(), course.getId());
    }
}
