package org.example.service;

import lombok.RequiredArgsConstructor;
import org.example.dto.StudentDetailDto;
import org.example.dto.StudentDto;
import org.example.model.School;
import org.example.model.Student;
import org.example.repository.SchoolRepository;
import org.example.repository.StudentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StudentService {
    private final StudentRepository studentRepository;
    private final SchoolRepository schoolRepository;

    @Transactional
    public StudentDto createStudent(StudentDto studentDto, Long schoolId) {
        School school = schoolRepository.findById(schoolId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "School not found"));
        if (studentDto.name() == null || studentDto.name().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Student name is required");
        }
        Student student = new Student();
        student.setName(studentDto.name());
        student.setSchool(school);
        student = studentRepository.save(student);
        return new StudentDto(student.getId(), student.getName());
    }

    public StudentDetailDto getStudentByName(String name) {
        Student student = studentRepository.findByName(name)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Student not found"));
        return new StudentDetailDto(
                student.getId(),
                student.getName(),
                student.getCourses().stream().map(c -> new org.example.dto.CourseDto(c.getId(), c.getName())).collect(Collectors.toList())
        );
    }

    public List<StudentDto> getAllStudents() {
        return studentRepository.findAll().stream()
                .map(s -> new StudentDto(s.getId(), s.getName()))
                .collect(Collectors.toList());
    }

    @Transactional
    public StudentDto updateStudent(String name, StudentDto studentDto) {
        Student student = studentRepository.findByName(name)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Student not found"));
        if (studentDto.name() == null || studentDto.name().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Student name is required");
        }
        student.setName(studentDto.name());
        student = studentRepository.save(student);
        return new StudentDto(student.getId(), student.getName());
    }

    @Transactional
    public void deleteStudent(String name) {
        Student student = studentRepository.findByName(name)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Student not found"));
        studentRepository.delete(student);
    }
}
