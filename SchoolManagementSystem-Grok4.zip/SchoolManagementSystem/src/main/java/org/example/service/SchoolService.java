package org.example.service;

import lombok.RequiredArgsConstructor;
import org.example.dto.SchoolDto;
import org.example.model.School;
import org.example.repository.SchoolRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SchoolService {
    private final SchoolRepository schoolRepository;
    private final StudentService studentService;
    private final CourseService courseService;
    private final InstructorService instructorService;

    public SchoolDto getSchoolByName(String name) {
        School school = schoolRepository.findByName(name)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "School not found"));
        return new SchoolDto(
                school.getId(),
                school.getName(),
                school.getInstructors().stream().map(i -> new org.example.dto.InstructorDto(i.getId(), i.getName())).collect(Collectors.toList()),
                school.getCourses().stream().map(c -> new org.example.dto.CourseDto(c.getId(), c.getName())).collect(Collectors.toList()),
                school.getStudents().stream().map(s -> new org.example.dto.StudentDto(s.getId(), s.getName())).collect(Collectors.toList())
        );
    }
}
