package org.example.service;

import lombok.RequiredArgsConstructor;
import org.example.dto.InstructorDetailDto;
import org.example.dto.InstructorDto;
import org.example.model.Instructor;
import org.example.model.School;
import org.example.repository.InstructorRepository;
import org.example.repository.SchoolRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class InstructorService {
    private final InstructorRepository instructorRepository;
    private final SchoolRepository schoolRepository;

    @Transactional
    public InstructorDto createInstructor(InstructorDto instructorDto, Long schoolId) {
        School school = schoolRepository.findById(schoolId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "School not found"));
        if (instructorDto.name() == null || instructorDto.name().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Instructor name is required");
        }
        Instructor instructor = new Instructor();
        instructor.setName(instructorDto.name());
        instructor.setSchool(school);
        instructor = instructorRepository.save(instructor);
        return new InstructorDto(instructor.getId(), instructor.getName());
    }

    public InstructorDetailDto getInstructorByName(String name) {
        Instructor instructor = instructorRepository.findByName(name)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Instructor not found"));
        return new InstructorDetailDto(
                instructor.getId(),
                instructor.getName(),
                instructor.getCourses().stream().map(c -> new org.example.dto.CourseDto(c.getId(), c.getName())).collect(Collectors.toList())
        );
    }

    public List<InstructorDto> getAllInstructors() {
        return instructorRepository.findAll().stream()
                .map(i -> new InstructorDto(i.getId(), i.getName()))
                .collect(Collectors.toList());
    }

    @Transactional
    public InstructorDto updateInstructor(String name, InstructorDto instructorDto) {
        Instructor instructor = instructorRepository.findByName(name)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Instructor not found"));
        if (instructorDto.name() == null || instructorDto.name().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Instructor name is required");
        }
        instructor.setName(instructorDto.name());
        instructor = instructorRepository.save(instructor);
        return new InstructorDto(instructor.getId(), instructor.getName());
    }

    @Transactional
    public void deleteInstructor(String name) {
        Instructor instructor = instructorRepository.findByName(name)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Instructor not found"));
        instructorRepository.delete(instructor);
    }
}
