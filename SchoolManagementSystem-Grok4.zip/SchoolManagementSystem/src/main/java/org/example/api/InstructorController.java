package org.example.api;

import lombok.RequiredArgsConstructor;
import org.example.dto.InstructorDetailDto;
import org.example.dto.InstructorDto;
import org.example.service.InstructorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/instructor")
@RequiredArgsConstructor
public class InstructorController {
    private final InstructorService instructorService;

    @PostMapping
    public ResponseEntity<InstructorDto> createInstructor(@RequestBody InstructorDto instructorDto, @RequestParam Long schoolId) {
        return ResponseEntity.status(201).body(instructorService.createInstructor(instructorDto, schoolId));
    }

    @GetMapping("/{name}")
    public ResponseEntity<InstructorDetailDto> getInstructorByName(@PathVariable String name) {
        return ResponseEntity.ok(instructorService.getInstructorByName(name));
    }

    @GetMapping
    public ResponseEntity<List<InstructorDto>> getAllInstructors() {
        return ResponseEntity.ok(instructorService.getAllInstructors());
    }

    @PutMapping("/{name}")
    public ResponseEntity<InstructorDto> updateInstructor(@PathVariable String name, @RequestBody InstructorDto instructorDto) {
        return ResponseEntity.ok(instructorService.updateInstructor(name, instructorDto));
    }

    @DeleteMapping("/{name}")
    public ResponseEntity<Void> deleteInstructor(@PathVariable String name) {
        instructorService.deleteInstructor(name);
        return ResponseEntity.ok().build();
    }
}
