package org.example.api;

import lombok.RequiredArgsConstructor;
import org.example.dto.CourseDetailDto;
import org.example.dto.CourseDto;
import org.example.service.CourseService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/course")
@RequiredArgsConstructor
public class CourseController {
    private final CourseService courseService;

    @PostMapping
    public ResponseEntity<CourseDto> createCourse(@RequestBody CourseDto courseDto, @RequestParam Long schoolId, @RequestParam(required = false) Long instructorId) {
        return ResponseEntity.status(201).body(courseService.createCourse(courseDto, schoolId, instructorId));
    }

    @GetMapping("/{name}")
    public ResponseEntity<CourseDetailDto> getCourseByName(@PathVariable String name) {
        return ResponseEntity.ok(courseService.getCourseByName(name));
    }

    @GetMapping
    public ResponseEntity<List<CourseDto>> getAllCourses() {
        return ResponseEntity.ok(courseService.getAllCourses());
    }

    @PutMapping("/{name}")
    public ResponseEntity<CourseDto> updateCourse(@PathVariable String name, @RequestBody CourseDto courseDto, @RequestParam(required = false) Long instructorId) {
        return ResponseEntity.ok(courseService.updateCourse(name, courseDto, instructorId));
    }

    @DeleteMapping("/{name}")
    public ResponseEntity<Void> deleteCourse(@PathVariable String name) {
        courseService.deleteCourse(name);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/{courseName}/students/{studentName}")
    public ResponseEntity<Void> addStudentToCourse(@PathVariable String courseName, @PathVariable String studentName) {
        courseService.addStudentToCourse(courseName, studentName);
        return ResponseEntity.ok().build();
    }
}
