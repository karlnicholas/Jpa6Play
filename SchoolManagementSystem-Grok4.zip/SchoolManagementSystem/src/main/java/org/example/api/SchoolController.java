package org.example.api;

import lombok.RequiredArgsConstructor;
import org.example.dto.SchoolDto;
import org.example.service.SchoolService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/school")
@RequiredArgsConstructor
public class SchoolController {
    private final SchoolService schoolService;

    @GetMapping("/{name}")
    public ResponseEntity<SchoolDto> getSchoolByName(@PathVariable String name) {
        return ResponseEntity.ok(schoolService.getSchoolByName(name));
    }
}
