package org.example.api;

import lombok.RequiredArgsConstructor;
import org.example.dto.*;
import org.example.service.CourseService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/course")
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courseService;

    @PostMapping
    public ResponseEntity<CourseDto> createCourse(@RequestBody CreateCourseRequest request) {
        return new ResponseEntity<>(courseService.createCourse(request), HttpStatus.CREATED);
    }

    @GetMapping("/{name}")
    public ResponseEntity<CourseDetailDto> getCourseByName(@PathVariable String name) {
        return ResponseEntity.ok(courseService.getCourseByName(name));
    }

    @GetMapping
    public ResponseEntity<List<CourseDto>> getAllCourses() {
        return ResponseEntity.ok(courseService.getAllCourses());
    }

    @PutMapping("/{name}")
    public ResponseEntity<CourseDto> updateCourse(@PathVariable String name, @RequestBody UpdateRequest request) {
        return ResponseEntity.ok(courseService.updateCourse(name, request));
    }

    @DeleteMapping("/{name}")
    public ResponseEntity<Void> deleteCourse(@PathVariable String name) {
        courseService.deleteCourse(name);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/{courseName}/students/{studentName}")
    public ResponseEntity<Void> addStudentToCourse(@PathVariable String courseName, @PathVariable String studentName) {
        courseService.addStudentToCourse(courseName, studentName);
        return ResponseEntity.ok().build();
    }
}
