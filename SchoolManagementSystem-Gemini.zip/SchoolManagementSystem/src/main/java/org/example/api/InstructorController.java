package org.example.api;

import lombok.RequiredArgsConstructor;
import org.example.dto.*;
import org.example.service.InstructorService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/instructor")
@RequiredArgsConstructor
public class InstructorController {
    
    private final InstructorService instructorService;

    @PostMapping
    public ResponseEntity<InstructorDto> createInstructor(@RequestBody CreateInstructorRequest request) {
        return new ResponseEntity<>(instructorService.createInstructor(request), HttpStatus.CREATED);
    }
    
    @GetMapping("/{name}")
    public ResponseEntity<InstructorDetailDto> getInstructorByName(@PathVariable String name) {
        return ResponseEntity.ok(instructorService.getInstructorByName(name));
    }
    
    @GetMapping
    public ResponseEntity<List<InstructorDto>> getAllInstructors() {
        return ResponseEntity.ok(instructorService.getAllInstructors());
    }
    
    @PutMapping("/{name}")
    public ResponseEntity<InstructorDto> updateInstructor(@PathVariable String name, @RequestBody UpdateRequest request) {
        return ResponseEntity.ok(instructorService.updateInstructor(name, request));
    }
    
    @DeleteMapping("/{name}")
    public ResponseEntity<Void> deleteInstructor(@PathVariable String name) {
        instructorService.deleteInstructor(name);
        return ResponseEntity.ok().build();
    }
}
