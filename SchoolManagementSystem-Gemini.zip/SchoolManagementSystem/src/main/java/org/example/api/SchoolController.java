package org.example.api;

import lombok.RequiredArgsConstructor;
import org.example.dto.CreateSchoolRequest;
import org.example.dto.SchoolDto;
import org.example.service.SchoolService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/school")
@RequiredArgsConstructor
public class SchoolController {
    
    private final SchoolService schoolService;
    
    @PostMapping
    public ResponseEntity<SchoolDto> createSchool(@RequestBody CreateSchoolRequest request) {
        // A simple POST to create a school, not in original reqs but useful for setup
        return new ResponseEntity<>(schoolService.createSchool(request), HttpStatus.CREATED);
    }

    @GetMapping("/{name}")
    public ResponseEntity<SchoolDto> getSchoolByName(@PathVariable String name) {
        return ResponseEntity.ok(schoolService.getSchoolByName(name));
    }
}
