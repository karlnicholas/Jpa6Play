package org.example.dto;
public record InstructorDto(Long id, String name) {}
