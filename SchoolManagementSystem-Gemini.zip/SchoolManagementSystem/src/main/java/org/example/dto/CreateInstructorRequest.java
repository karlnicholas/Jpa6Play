package org.example.dto;
public record CreateInstructorRequest(String name, String schoolName) {}
