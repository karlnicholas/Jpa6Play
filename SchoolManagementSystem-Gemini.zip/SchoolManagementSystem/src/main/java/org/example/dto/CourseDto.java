package org.example.dto;
public record CourseDto(Long id, String name) {}
