package org.example.dto;
public record CreateSchoolRequest(String name) {}
