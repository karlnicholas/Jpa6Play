package org.example.dto;
public record UpdateRequest(String newName) {}
