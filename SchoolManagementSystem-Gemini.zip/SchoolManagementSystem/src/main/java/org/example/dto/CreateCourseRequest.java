package org.example.dto;
public record CreateCourseRequest(String name, String schoolName, String instructorName) {}
