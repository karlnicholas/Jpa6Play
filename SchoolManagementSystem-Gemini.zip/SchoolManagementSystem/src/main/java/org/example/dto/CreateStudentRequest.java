package org.example.dto;
public record CreateStudentRequest(String name, String schoolName) {}
