package org.example.dto;
public record StudentDto(Long id, String name) {}
