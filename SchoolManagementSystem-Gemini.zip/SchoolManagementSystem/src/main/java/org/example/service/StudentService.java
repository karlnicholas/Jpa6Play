package org.example.service;

import lombok.RequiredArgsConstructor;
import org.example.dto.*;
import org.example.exception.ResourceNotFoundException;
import org.example.mapper.EntityDtoMapper;
import org.example.model.School;
import org.example.model.Student;
import org.example.repository.SchoolRepository;
import org.example.repository.StudentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentRepository studentRepository;
    private final SchoolRepository schoolRepository;

    @Transactional
    public StudentDto createStudent(CreateStudentRequest request) {
        School school = schoolRepository.findByName(request.schoolName())
                .orElseThrow(() -> new ResourceNotFoundException("School not found: " + request.schoolName()));
        Student student = new Student();
        student.setName(request.name());
        student.setSchool(school);
        return EntityDtoMapper.toStudentDto(studentRepository.save(student));
    }
    
    @Transactional(readOnly = true)
    public StudentDetailDto getStudentByName(String name) {
        Student student = studentRepository.findByName(name)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with name: " + name));
        student.getCourses().size(); // Initialize courses
        return EntityDtoMapper.toStudentDetailDto(student);
    }

    public List<StudentDto> getAllStudents() {
        return studentRepository.findAll().stream()
                .map(EntityDtoMapper::toStudentDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public StudentDto updateStudent(String name, UpdateRequest request) {
        Student student = studentRepository.findByName(name)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with name: " + name));
        student.setName(request.newName());
        return EntityDtoMapper.toStudentDto(studentRepository.save(student));
    }

    @Transactional
    public void deleteStudent(String name) {
        Student student = studentRepository.findByName(name)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with name: " + name));
        studentRepository.delete(student);
    }
}
