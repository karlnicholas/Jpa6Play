package org.example.service;

import lombok.RequiredArgsConstructor;
import org.example.dto.*;
import org.example.exception.ResourceNotFoundException;
import org.example.mapper.EntityDtoMapper;
import org.example.model.Course;
import org.example.model.Instructor;
import org.example.model.School;
import org.example.model.Student;
import org.example.repository.CourseRepository;
import org.example.repository.InstructorRepository;
import org.example.repository.SchoolRepository;
import org.example.repository.StudentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CourseService {
    private final CourseRepository courseRepository;
    private final StudentRepository studentRepository;
    private final SchoolRepository schoolRepository;
    private final InstructorRepository instructorRepository;

    @Transactional
    public CourseDto createCourse(CreateCourseRequest request) {
        School school = schoolRepository.findByName(request.schoolName())
                .orElseThrow(() -> new ResourceNotFoundException("School not found: " + request.schoolName()));
        Instructor instructor = instructorRepository.findByName(request.instructorName())
                .orElseThrow(() -> new ResourceNotFoundException("Instructor not found: " + request.instructorName()));

        Course course = new Course();
        course.setName(request.name());
        course.setSchool(school);
        course.setInstructor(instructor);
        return EntityDtoMapper.toCourseDto(courseRepository.save(course));
    }

    @Transactional(readOnly = true)
    public CourseDetailDto getCourseByName(String name) {
        Course course = courseRepository.findByName(name)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with name: " + name));
        course.getStudents().size(); // Initialize students collection
        return EntityDtoMapper.toCourseDetailDto(course);
    }

    @Transactional(readOnly = true)
    public List<CourseDto> getAllCourses() {
        return courseRepository.findAll().stream()
                .map(EntityDtoMapper::toCourseDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public CourseDto updateCourse(String name, UpdateRequest request) {
        Course course = courseRepository.findByName(name)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with name: " + name));
        course.setName(request.newName());
        return EntityDtoMapper.toCourseDto(courseRepository.save(course));
    }

    @Transactional
    public void deleteCourse(String name) {
        Course course = courseRepository.findByName(name)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with name: " + name));
        
        for(Student student : new HashSet<>(course.getStudents())) {
            student.getCourses().remove(course);
        }
        
        courseRepository.delete(course);
    }

    @Transactional
    public void addStudentToCourse(String courseName, String studentName) {
        Student student = studentRepository.findByName(studentName)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with name: " + studentName));
        Course course = courseRepository.findByName(courseName)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with name: " + courseName));
        
        student.getCourses().add(course);
        studentRepository.save(student);
    }
}
