package org.example.service;

import lombok.RequiredArgsConstructor;
import org.example.dto.CreateSchoolRequest;
import org.example.dto.SchoolDto;
import org.example.exception.ResourceNotFoundException;
import org.example.mapper.EntityDtoMapper;
import org.example.model.School;
import org.example.repository.SchoolRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class SchoolService {

    private final SchoolRepository schoolRepository;

    public SchoolDto createSchool(CreateSchoolRequest request) {
        School school = new School();
        school.setName(request.name());
        return EntityDtoMapper.toSchoolDto(schoolRepository.save(school));
    }

    @Transactional(readOnly = true)
    public SchoolDto getSchoolByName(String name) {
        School school = schoolRepository.findByName(name)
                .orElseThrow(() -> new ResourceNotFoundException("School not found with name: " + name));
        // Eagerly fetch collections for the DTO
        school.getStudents().size();
        school.getCourses().size();
        school.getInstructors().size();
        return EntityDtoMapper.toSchoolDto(school);
    }
}
