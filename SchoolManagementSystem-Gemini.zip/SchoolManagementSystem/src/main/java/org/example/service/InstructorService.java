package org.example.service;

import lombok.RequiredArgsConstructor;
import org.example.dto.*;
import org.example.exception.ResourceNotFoundException;
import org.example.mapper.EntityDtoMapper;
import org.example.model.Instructor;
import org.example.model.School;
import org.example.repository.InstructorRepository;
import org.example.repository.SchoolRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class InstructorService {
    private final InstructorRepository instructorRepository;
    private final SchoolRepository schoolRepository;

    @Transactional
    public InstructorDto createInstructor(CreateInstructorRequest request) {
        School school = schoolRepository.findByName(request.schoolName())
                .orElseThrow(() -> new ResourceNotFoundException("School not found: " + request.schoolName()));
        Instructor instructor = new Instructor();
        instructor.setName(request.name());
        instructor.setSchool(school);
        return EntityDtoMapper.toInstructorDto(instructorRepository.save(instructor));
    }

    @Transactional(readOnly = true)
    public InstructorDetailDto getInstructorByName(String name) {
        Instructor instructor = instructorRepository.findByName(name)
                .orElseThrow(() -> new ResourceNotFoundException("Instructor not found with name: " + name));
        instructor.getCourses().size(); // Initialize courses
        return EntityDtoMapper.toInstructorDetailDto(instructor);
    }

    public List<InstructorDto> getAllInstructors() {
        return instructorRepository.findAll().stream()
                .map(EntityDtoMapper::toInstructorDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public InstructorDto updateInstructor(String name, UpdateRequest request) {
        Instructor instructor = instructorRepository.findByName(name)
                .orElseThrow(() -> new ResourceNotFoundException("Instructor not found with name: " + name));
        instructor.setName(request.newName());
        return EntityDtoMapper.toInstructorDto(instructorRepository.save(instructor));
    }

    @Transactional
    public void deleteInstructor(String name) {
        Instructor instructor = instructorRepository.findByName(name)
                .orElseThrow(() -> new ResourceNotFoundException("Instructor not found with name: " + name));
        instructorRepository.delete(instructor);
    }
}
